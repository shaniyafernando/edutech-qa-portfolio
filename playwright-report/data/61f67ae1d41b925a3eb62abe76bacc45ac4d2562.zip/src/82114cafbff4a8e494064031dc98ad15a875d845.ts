import { Page } from '@playwright/test';

export default class HomePage {

    constructor(private page: Page) {}

    async getArticlePreviewCount() {
        return await this.page.locator("app-article-list").count();
    }

    async getArticlePreviewElements(i: number) {
    const author = await this.page.locator("app-article-list").nth(i).locator("article-meta");
        const title = await this.page.locator("app-article-list").nth(i).locator("h1");
        const description = await this.page.locator("app-article-list").nth(i).locator("p");
        const readMore = await this.page.locator("app-article-preview").nth(i).locator("a.preview-link span", { hasText: "Read more..." });
        const favoriteButton = await this.page.locator("app-article-list").nth(i).locator("button.btn.btn-sm.btn-outline-primary > i.ion-heart")
        return { author, title, description, readMore, favoriteButton };
    }
}