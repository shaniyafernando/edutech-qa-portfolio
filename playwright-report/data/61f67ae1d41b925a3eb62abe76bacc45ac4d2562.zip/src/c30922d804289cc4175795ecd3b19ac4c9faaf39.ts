import { test, expect } from "@playwright/test";
import HomePage from "../pages/home-page";

test.use({ storageState: { cookies: [], origins: [] } });

test.only('ETQP-BP-01 Global Feed accessibility for guest users', async ({ page }) =>{
    
    await page.goto("/");
    await expect(page).toHaveTitle("Conduit");
    await expect(page.getByRole("heading", { name: "Conduit" }).getByRole("img", { name: "Conduit", exact: true })).toBeVisible();
    await expect(page.getByRole("link", { name: "Global Feed" })).toHaveText("Global Feed");

    const homePage = new HomePage(page)
    const globalFeedTotalArticles = await homePage.getArticlePreviewCount();
    console.log("Total articles in Global Feed: ", globalFeedTotalArticles);
    expect(globalFeedTotalArticles).toBeGreaterThan(0);

    for (let i = 0; i < globalFeedTotalArticles; i++) {
        const { author, title, description, readMore, favoriteButton } = await homePage.getArticlePreviewElements(i);
        expect(await author).toBeVisible();
        expect(await title).toBeVisible();
        expect(await description).toBeVisible();
        expect(await readMore).toBeVisible();
        expect(await favoriteButton).toBeVisible();
    }

    expect(await page.getByRole("link", { name: "Home" })).toBeVisible();
    expect(await page.getByRole("link", { name: "Sign in" })).toBeVisible();
    expect(await page.getByRole("link", { name: "Sign up" })).toBeVisible();
    expect(await page.getByRole("link", { name: "Settings" })).not.toBeVisible();
    expect(await page.getByRole("link", { name: "New Article" })).not.toBeVisible();
})

